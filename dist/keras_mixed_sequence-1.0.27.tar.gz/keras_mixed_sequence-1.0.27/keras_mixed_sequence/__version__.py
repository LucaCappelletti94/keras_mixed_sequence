"""Current version of package keras_mixed_sequence."""
__version__ = "1.0.27"
